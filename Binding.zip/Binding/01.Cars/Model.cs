﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _01.Cars
{
    public class Model
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
